let input1 = window.prompt("Enter first number: ");
let input2 = window.prompt("Enter second number: ");
var num1 = Number(input1);
var num2 = Number(input2);
window.prompt("Enter a math operator (+,-,*,/): ");
function calculate(num1, operation, num2) {
   let result; 
   switch (operation) {
     case "+":
       result = num1 + num2;
       break;
     case "-":
       result = num1 - num2;
       break;
     case "*":
       result = num1 * num2;
       break;
     case "/":
       result = num1 / num2;
       break;
   }
   return result;
 }
 
 console.log(calculate(`${num1}`, "+", `${num2}`));
 console.log(calculate(num1, "-", num2)); 
 console.log(calculate(num1, "*", num2)); 
 console.log(calculate(num1, "/", num2));