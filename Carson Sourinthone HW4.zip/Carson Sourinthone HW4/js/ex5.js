const word = prompt("Enter a word: ");

let vowelCount= 0;
let palindrome= "";
word.forEach(letter => {
    const lowerCase = letter.toLowerCase();
    if(
        lowerCase === "a" ||
        lowerCase === "e" || 
        lowerCase === "i" || 
        lowerCase === "o" ||
        lowerCase === "u" || 
        lowerCase === "y" || 
    ) {
        vowelCount++; 
    }
})
    