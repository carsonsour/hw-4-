const words = [];
let word = "";
while(word !=="stop"){
    word = prompt("Enter a word or stop to end:");
    if (word !=="stop"){
        words.push(word);
    }
}

console.log("These are your words: ");
words.forEach(x => {
    console.log(x);
});